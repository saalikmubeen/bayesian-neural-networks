# Supplementary code: "Is the Bayesian OOD Advantage Just Softness?"

- `bnnstudy/` — models, training (`bnnstudy.train`), the softness-matched
  evaluation (`bnnstudy.evaluate`, `bnnstudy.compare`), training dynamics, and
  full-batch HMC (`bnnstudy.hmc_batch`).
- `scripts/` — the run and analysis script for each experiment.
- `experiments/` — the pre-registered protocol of each experiment (E1–E23),
  with predictions written before the run and the result added after it;
  `E*_prereg.txt` hold the SHA-256 hashes recorded before launch. Protocols
  and experiment-specific scripts are unchanged since; shared modules (e.g.
  `bnnstudy/data.py`, `bnnstudy/train.py`) were extended by later experiments,
  so their hashes match the version at that experiment's launch. Each
  protocol's result section was added after the run;
  `python scripts/verify_prereg.py` checks that the text above it is exactly
  what was hashed before launch.
- `COMMANDS.md` — every command, in order.

Requirements in `requirements.txt` (PyTorch 1.9, CUDA 11.1). Run scripts use
the interpreter in `$PY` (set `PY=python` or your environment's path). Datasets
are downloaded by torchvision into `./data`.
